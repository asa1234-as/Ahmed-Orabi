-- ملف جديد (إضافة فقط): مخزن فيديوهات المنتجات. تم تنفيذه فعلًا على مشروع Supabase.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('product-videos', 'product-videos', true, 52428800, array['video/mp4','video/webm','video/quicktime'])
on conflict (id) do nothing;

drop policy if exists "public read product images" on storage.objects;
create policy "public read product images" on storage.objects
  for select using (bucket_id in ('product-images','product-videos'));
drop policy if exists "admins upload product images" on storage.objects;
create policy "admins upload product images" on storage.objects
  for insert to authenticated with check (bucket_id in ('product-images','product-videos') and public.is_admin());
drop policy if exists "admins update product images" on storage.objects;
create policy "admins update product images" on storage.objects
  for update to authenticated using (bucket_id in ('product-images','product-videos') and public.is_admin())
  with check (bucket_id in ('product-images','product-videos') and public.is_admin());
drop policy if exists "admins delete product images" on storage.objects;
create policy "admins delete product images" on storage.objects
  for delete to authenticated using (bucket_id in ('product-images','product-videos') and public.is_admin());
